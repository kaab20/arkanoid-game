import game.Game;

/**
 * @author Kamar asli
 * ID:214084709
 */
public class Ass5Game {
    /**
     * Initializing the game and running.
     *
     * @param args command line arguments.
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}