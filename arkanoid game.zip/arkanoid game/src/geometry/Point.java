package geometry;

/**
 * ID:214084709
 * @author kamar asli
 */
/**
 * Represents a point in a 2D space with x and y coordinates.
 */
public class Point {
    private double x;
    private double y;
    /**
     * Creates a new Point with the specified coordinates.
     *
     * @param x the x-coordinate of the point
     * @param y the y-coordinate of the point
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }
    /**
     * Gets the x-coordinate of the point.
     *
     * @return the x-coordinate
     */
    public double getX() {
        return this.x;
    }
    /**
     * Gets the y-coordinate of the point.
     *
     * @return the y-coordinate
     */
    public double getY() {
        return this.y;
    }
    /**
     * Sets the x-coordinate of the point.
     *
     * @param x the new x-coordinate
     */
    public void setX(double x) {
        this.x = x;
    }
    /**
     * Sets the y-coordinate of the point.
     *
     * @param y the new y-coordinate
     */
    public void setY(double y) {
        this.y = y;
    }
    /**
     * Calculates the distance between this point and another point.
     *
     * @param p the other point
     * @return the Euclidean distance between the two points
     */
    public double distance(Point p) {
        double dx = this.x - p.x;
        double dy = this.y - p.y;
        double res = Math.sqrt(dx * dx + dy * dy);
        return res;
    }

}
