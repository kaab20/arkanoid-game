package geometry;

import java.util.ArrayList;
import java.util.List;
/**
 * ID:214084709.
 * @author kamar asli
 */
public class Rectangle extends java.awt.Rectangle {
    private final Point upperLeft;
    private final double width;
    private final double height;
    /**
     * Constructs a Rectangle with the specified position and dimensions.
     *
     * @param x      the x-coordinate of the rectangle's upper-left corner
     * @param y      the y-coordinate of the rectangle's upper-left corner
     * @param width  the width of the rectangle
     * @param height the height of the rectangle
     */
    public Rectangle(double x, double y, double width, double height) {
        this(new Point(x, y), width, height);
    }
    /**
     * Constructs a Rectangle with the specified upper-left corner and dimensions.
     *
     * @param upperLeft the point representing the upper-left corner of the rectangle
     * @param width     the width of the rectangle
     * @param height    the height of the rectangle
     */
    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        this.width = width;
        this.height = height;
    }
    /**
     * Calculates the intersection points between the given line and the rectangle's sides.
     *
     * @param line the line to check for intersections with the rectangle
     * @return a list of intersection points, or an empty list if there are none
     */
    public List<Point> intersectionPoints(Line line) {
        List<Point> points = new ArrayList<>();
        Line[] sides = {
                new Line(upperLeft.getX(), upperLeft.getY(), upperLeft.getX() + width, upperLeft.getY()),
                new Line(upperLeft.getX(), upperLeft.getY(), upperLeft.getX(), upperLeft.getY() + height),
                new Line(upperLeft.getX() + width, upperLeft.getY(), upperLeft.getX() + width,
                        upperLeft.getY() + height),
                new Line(upperLeft.getX(), upperLeft.getY() + height, upperLeft.getX() + width,
                        upperLeft.getY() + height),
        };
        int i = 0;
        while (i < sides.length) {
            Point intersection = line.intersectionWith(sides[i]);
            if (intersection != null && !points.contains(intersection)) {
                points.add(intersection);
            }
            i++;
        }

        return points;
    }

    /**
     * Returns the upper-left corner point of the rectangle.
     *
     * @return the upper-left point of the rectangle
     */
    public Point getUpperLeft() {
        return this.upperLeft;
    }

    /**
     * Returns the width of the rectangle.
     *
     * @return the width of the rectangle
     */
    public double getWidth() {
        return width;
    }


    /**
     * Returns the height of the rectangle.
     *
     * @return the height of the rectangle
     */
    public double getHeight() {
        return height;
    }


}
