package geometry;

/**
 * * ID:214084709.
 * @author kamar asli
 */
/**
 * The Velocity class represents the velocity of an object in a two-dimensional space.
 * It encapsulates the horizontal (dx) and vertical (dy) components of the velocity
 * and provides methods to manipulate and retrieve these values.
 */
public class Velocity {
    private double dx;
    private double dy;
    /**
     * Constructs a Velocity object with specified horizontal and vertical components.
     *
     * @param dx the horizontal component of the velocity.
     * @param dy the vertical component of the velocity.
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }
    /**
     * Applies the velocity to a given point, returning a new point
     * that represents the point moved by this velocity.
     *
     * @param p the point to which the velocity is applied
     * @return a new point after applying the velocity
     */

    public Point applyToPoint(Point p) {
        return new Point(p.getX() + this.dx, p.getY() + this.dy);
    }
    /**
     * Creates a velocity from a specified angle and speed.
     * The angle is measured in degrees, where 0 degrees points right.
     *
     * @param angle the angle in degrees
     * @param speed the speed of the velocity
     * @return a Velocity object representing the direction and speed
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double radian = Math.toRadians(angle);
        double dx = speed * Math.sin(radian);
        double dy = -speed * Math.cos(radian);
        Velocity res = new Velocity(dx, dy);
        return res;
    }

    /**
     * Returns the horizontal component of the velocity.
     *
     * @return the horizontal component (dx)
     */
    public double getDx() {
        return this.dx;
    }

    /**
     * Returns the vertical component of the velocity.
     *
     * @return the vertical component (dy)
     */
    public double getDy() {
        return this.dy;
    }

    /**
     * Returns the horizontal component of the velocity (dx).
     *
     * @return the horizontal component (dx).
     */
    public double getDX() {
        return this.dx;
    }

    /**
     * Returns the vertical component of the velocity (dy).
     *
     * @return the vertical component (dy).
     */
    public double getDY() {
        return this.dy;
    }
}
