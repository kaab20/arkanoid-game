package geometry;

import java.util.List;
/**
 * ID:214084709
 * @author kamar asli
 */
/**
 * Represents a line segment defined by two endpoints in a 2D space.
 * This class provides methods to calculate the line's properties,
 * check for intersections with other lines, and find the closest
 * intersection point with a given rectangle.
 */
public class Line {
    private Point start;
    private Point end;
    /**
     * Constructs a Line object using two Point objects as endpoints.
     *
     * @param start the starting point of the line
     * @param end   the ending point of the line
     */
    public Line(Point start, Point end) {
        this.start = start;
        this.end = end;
    }
    /**
     * Constructs a Line object using coordinates for the endpoints.
     *
     * @param x1 the x-coordinate of the starting point
     * @param y1 the y-coordinate of the starting point
     * @param x2 the x-coordinate of the ending point
     * @param y2 the y-coordinate of the ending point
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.start = new Point(x1, y1);
        this.end = new Point(x2, y2);
    }

    /**
     * Calculates the length of the line segment.
     *
     * @return the length of the line
     */
    public double length() {
        double res = this.start.distance(this.end);
        return res;
    }
    /**
     * Gets the ending point of the line.
     *
     * @return a Point representing the end of the line
     */
    public Point end() {
        double xcoo = this.end.getX();
        double ycoo = this.end.getY();
        return new Point(xcoo, ycoo);
    }
    /**
     * Gets the starting point of the line.
     *
     * @return a Point representing the start of the line
     */
    public Point start() {
        double xcoo = this.start.getX();
        double ycoo = this.start.getY();
        return new Point(xcoo, ycoo);
    }
    /**
     * Checks if two double values are approximately equal.
     *
     * @param a the first value
     * @param b the second value
     * @return true if the values are approximately equal, false otherwise
     */
    private boolean approxEqual(double a, double b) {
        boolean res = Math.abs(a - b) < 1.0E-10;
        return res;
    }
    /**
     * Checks if two points are approximately equal.
     *
     * @param p1 the first point
     * @param p2 the second point
     * @return true if the points are approximately equal, false otherwise
     */
    private boolean approxEqual(Point p1, Point p2) {
        boolean resX = this.approxEqual(p1.getX(), p2.getX());
        boolean resY = this.approxEqual(p1.getY(), p2.getY());
        boolean res = resX && resY;
        return res;
    }
    /**
     * Checks if this line is equal to another line.
     *
     * @param other the line to compare with
     * @return true if the lines are equal, false otherwise
     */
    public boolean equals(Line other) {
        return this.approxEqual(this.start, other.start)
                && this.approxEqual(this.end, other.end)
                || this.approxEqual(this.start, other.end)
                && this.approxEqual(this.end, other.start);
    }
    /**
     * Determines the orientation of the ordered triplet (p, q, r).
     *
     * @param p the first point
     * @param q the second point
     * @param r the third point
     * @return 0 if collinear, 1 if clockwise, 2 if counterclockwise
     */
    private int orientation(Point p, Point q, Point r) {
        double val = (q.getY() - p.getY()) * (r.getX() - q.getX()) - (q.getX() - p.getX()) * (r.getY() - q.getY());
        if (this.approxEqual(val, 0.0)) {
            return 0;
        } else {
            return val > 0.0 ? 1 : 2;
        }
    }
    /**
     * Checks if point q lies on the line segment pr.
     *
     * @param p the starting point of the segment
     * @param q the point to check
     * @param r the ending point of the segment
     * @return true if q lies on the segment pr, false otherwise
     */
    private boolean onSegment(Point p, Point q, Point r) {
        double minX = Math.min(p.getX(), r.getX());
        double maxX = Math.max(p.getX(), r.getX());
        double minY = Math.min(p.getY(), r.getY());
        double maxY = Math.max(p.getY(), r.getY());

        return (q.getX() >= minX && q.getX() <= maxX) && (q.getY() >= minY && q.getY() <= maxY);
    }

    /**
     * Checks if this line intersects with another line.
     *
     * @param other the other line to check for intersection
     * @return true if the lines intersect, false otherwise
     */
    public boolean isIntersecting(Line other) {
        Point p1 = this.start;
        Point q1 = this.end;
        Point p2 = other.start;
        Point q2 = other.end;
        int o1 = this.orientation(p1, q1, p2);
        int o2 = this.orientation(p1, q1, q2);
        int o3 = this.orientation(p2, q2, p1);
        int o4 = this.orientation(p2, q2, q1);
        if (o1 != o2 && o3 != o4) {
            return true;
        } else {
            return o1 == 0 && this.onSegment(p1, p2, q1)
                    || o2 == 0 && this.onSegment(p1, q2, q1)
                    || o3 == 0 && this.onSegment(p2, p1, q2)
                    || o4 == 0 && this.onSegment(p2, q1, q2);
        }
    }
    /**
     * Calculates the intersection point of this line with another line.
     *
     * @param other the other line
     * @return the intersection point if they intersect, null otherwise
     */
    public Point intersectionWith(Line other) {
        if (!this.isIntersecting(other)) {
            return null;
        } else {
            Point p1 = this.start;
            Point q1 = this.end;
            Point p2 = other.start;
            Point q2 = other.end;
            if (this.equals(other)) {
                return null;
            } else {
                double x1 = p1.getX(); double y1 = p1.getY(); double x2 = q1.getX();
                double y2 = q1.getY(); double x3 = p2.getX(); double y3 = p2.getY();
                double x4 = q2.getX(); double y4 = q2.getY();
                double mekhane = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
                if (this.approxEqual(mekhane, 0.0)) {
                    return null;
                } else {
                    double pos = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / mekhane;
                    double intersectionY = y1 + pos * (y2 - y1);
                    double intersectionX = x1 + pos * (x2 - x1);
                    Point res = new Point(intersectionX, intersectionY);
                    return res;
                }
            }
        }
    }
    /**
     * Finds the closest intersection point to the start of the line with a given rectangle.
     *
     * @param rect the rectangle to check for intersections
     * @return the closest intersection point, or null if there are no intersections
     */
    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        Line curLine = null;
        try {
            curLine = new Line(this.start, this.end);
        } catch (Exception var) {
            System.out.println(var.getMessage());
        }
        List<Point> intersectionPoints = rect.intersectionPoints(curLine);
        return intersectionPoints.isEmpty() ? null : findClosestPoint(intersectionPoints);
    }
    /**
     * Helper method to find the closest point to the start of the line from the list of intersection points.
     *
     * @param intersectionPoints a list of intersection points to search through.
     * @return the closest point to the start of the line from the provided list of intersection points.
     */
    private Point findClosestPoint(List<Point> intersectionPoints) {
        int n = intersectionPoints.size();
        boolean swapped;
        do {
            swapped = false;

            for (int i = 0; i < n - 1; ++i) {
                Point p1 = intersectionPoints.get(i);
                Point p2 = intersectionPoints.get(i + 1);
                if (this.start.distance(p1) > this.start.distance(p2)) {
                    intersectionPoints.set(i, p2);
                    intersectionPoints.set(i + 1, p1);
                    swapped = true;
                }
            }

            --n;
        } while (swapped);

        return intersectionPoints.get(0); // Return the closest point
    }
    /**
     * Creates a new Line object extended from the end of this line by a specified length.
     *
     * @param l the length to extend the line
     * @return a new Line object extended from this line
     */
    public Line harakha(double l) {
        double lineLength = length();
        double direcX = (end.getX() - start.getX()) / lineLength;
        double direcY = (end.getY() - start.getY()) / lineLength;
        double newX = end.getX() + l * direcX;
        double newY = end.getY() + l * direcY;
        return new Line(start, new Point(newX, newY));
    }

}
