package logic;

import game.Game;
import sprites.Ball;
import sprites.Block;
import utils.Counter;
/**
 * @author Kamar asli
 * ID:214084709
 */
public class BallRemover implements HitListener {
    private final Game game;
    private final Counter remainingBalls;

    /**
     * Constructor.
     *
     * @param game           a Game.
     * @param rBalls Counter of the remaining balls.
     */
    public BallRemover(Game game, Counter rBalls) {
        this.game = game;
        this.remainingBalls = rBalls;
    }

    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeFromGame(game);
        remainingBalls.decrease(1);
    }
}