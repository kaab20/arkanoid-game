package logic;

/**
 * ID:214084709
 * @author kamar asli
 */

import geometry.Point;

/**
 * The CollisionInfo class represents information about a collision event.
 * It includes the point of collision and the object involved in the collision.
 */
public class CollisionInfo {
    private Point collPoint;
    private Collidable collObj;
    /**
     * Constructs a CollisionInfo object.
     *
     * @param collisionP the point at which the collision occurs.
     * @param collisionObj the object involved in the collision.
     */
    public CollisionInfo(Point collisionP, Collidable collisionObj) {
        this.collPoint = collisionP;
        this.collObj = collisionObj;
    }

    /**
     * @return the point of collision .
     */
    public Point collisionPoint() {
        return this.collPoint;
    }
    /**
     * @return the collidable object  in the collision.
     */
    public Collidable collisionObject() {
        return this.collObj;
    }
}
