package logic;

/**
 * ID:214084709.
 * @author kamar asli
 */

import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;
import sprites.Ball;

/**
 * Represents an object that can be collided with in the game.
 */
public interface Collidable {

    /**
     * @return the collision rectangle of the object.
     */
    Rectangle getCollisionRectangle();

    /**
     * Handles the collision logic and updates the velocity based on the collision point.
     *
     * @param var2 the point where the collision occurred.
     * @param var3 the velocity of the object before the collision.
     * @return the new velocity after the collision.
     */
    Velocity hit(Ball hitter, Point var2, Velocity var3);
}
