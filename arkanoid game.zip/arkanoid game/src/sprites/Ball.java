package sprites;

/**
 * ID:214084709
 * @author kamar asli
 */
import biuoop.DrawSurface;
import collections.GameEnvironment;
import game.Game;
import geometry.Line;
import geometry.Point;
import geometry.Velocity;
import logic.CollisionInfo;


import java.awt.Color;
/** The Ball class represents a ball in the game.
 * It can move, interact with the game environment, and be drawn on the screen.
 * Each ball has a position, size, color, velocity, and game environment.
 * The Ball also implements the Sprite interface.
 */
public class Ball implements Sprite {
    private Velocity velocity = new Velocity(0, 0);
    private GameEnvironment gameEnvironment;
    private final int size;
    private Color color;
    private Point p;

    /**
     * Constructor.
     *
     * @param point the center of the ball.
     * @param r     the size of the ball.
     * @param clr the color of the ball.
     */
    public Ball(Point point, int r, Color clr) {
        this.p = point;
        this.size = r;
        this.color = clr;
    }
    /**
     * Constructor that receives the coordinates of the center.
     * @param x     the center's x coordinate.
     * @param y     the center's y coordinate.
     * @param r     the size of the ball.
     * @param clr the color of the ball.
     */
    public Ball(double x, double y, int r, Color clr) {
        this(new Point(x, y), r, clr);
    }
    /**
     * @return the ball center's x coordinate.
     */
    public int getX() {
        return ((int) p.getX());
    }
    /**
     * @return the ball center's y coordinate.
     */
    public int getY() {
        return ((int) p.getY());
    }
    /**
     * Updates the ball's velocity.
     *
     * @param v the new velocity.
     */
    public void setVelocity(Velocity v) {
        this.velocity = v;
    }

    /**
     * Sets the game environment.
     *
     * @param env GameEnvironment.
     */
    public void setGameEnvironment(GameEnvironment env) {
        this.gameEnvironment = env;
    }
    /**
     * Draw the ball on the given DrawSurface.
     *
     * @param sur a surface to draw on.
     */
    @Override
    public void drawOn(DrawSurface sur) {
        sur.setColor(color);
        sur.fillCircle(getX(), getY(), size);
    }
    /**
     * Moving the point one step according to the velocity.
     * If the ball hits a collidable, changing the velocity.
     */
    public void moveOneStep() {
        Line maslol = new Line(p, velocity.applyToPoint(p));
        CollisionInfo collisionInfo = gameEnvironment.getClosestCollision(maslol.harakha(size));
        if (collisionInfo != null) {
            this.velocity = collisionInfo.collisionObject().hit(this, collisionInfo.collisionPoint(), velocity);
        } else {
            this.p = maslol.end();
        }
    }
    @Override
    public void timePassed() {
        moveOneStep();
    }
    /**
     * Adds the ball to the sprites collection in the game.
     *
     * @param game a Game.
     */
    public void addToGame(Game game) {
        game.addSprite(this);
    }

    public void removeFromGame(Game game) {
        game.removeSprite(this);
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

}