package sprites;

import biuoop.KeyboardSensor;
import geometry.Velocity;
import geometry.Rectangle;
import geometry.Point;
import logic.Collidable;

import java.awt.Color;

/**
 * ID:214084709
 * Author: Kamar Asli
 */
public class Paddle extends Block implements Sprite, Collidable {
    private biuoop.KeyboardSensor keyboard;
    private double speed;

    /**
     * Constructs a Paddle object.
     *
     * @param keyboard the KeyboardSensor to detect user input for controlling the paddle
     * @param rec      the Rectangle representing the paddle's position and size
     * @param clr      the Color of the paddle
     */
    public Paddle(KeyboardSensor keyboard, Rectangle rec, Color clr, double speed) {
        super(rec, clr);
        this.keyboard = keyboard;
        this.speed = speed;
    }
    public Paddle(KeyboardSensor keyboard, Rectangle rec, Color clr) {
        super(rec, clr);
        this.keyboard = keyboard;
        this.speed = 10;
    }

    /**
     * Moves the paddle to the left by a specified speed.
     * Ensures the paddle does not move beyond the left boundary of the screen.
     */
    public void moveLeft() {
        double newX = getCollisionRectangle().getUpperLeft().getX() - speed;

        if (newX + getCollisionRectangle().getWidth() < 0) {
            newX = 790;
        }

        Point newUpperLeft = new Point(newX, getCollisionRectangle().getUpperLeft().getY());
        setCollisionRectangle(new Rectangle(newUpperLeft,
                getCollisionRectangle().getWidth(),
                getCollisionRectangle().getHeight()));
    }

    public void moveRight() {
        double newX = getCollisionRectangle().getUpperLeft().getX() + speed;

        if (newX > 790) {
            newX = -getCollisionRectangle().getWidth();
        }

        Point newUpperLeft = new Point(newX, getCollisionRectangle().getUpperLeft().getY());
        setCollisionRectangle(new Rectangle(newUpperLeft,
                getCollisionRectangle().getWidth(),
                getCollisionRectangle().getHeight()));
    }

    /**
     * Updates the paddle's position based on user input.
     */
    @Override
    public void timePassed() {
        if (keyboard.isPressed(KeyboardSensor.LEFT_KEY)) {
            moveLeft();
        } else if (keyboard.isPressed(KeyboardSensor.RIGHT_KEY)) {
            moveRight();
        }
    }

    /**
     * Calculates the new velocity of the ball after a collision with the paddle.
     * The return angle depends on the collision point on the paddle's surface.
     *
     * @param collisionPoint   the point where the ball hits the paddle
     * @param currentVelocity  the current velocity of the ball
     * @return a new Velocity object representing the ball's post-collision speed and direction
     */
    @Override
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        double speed = Math.sqrt(Math.pow(currentVelocity.getDx(), 2) + Math.pow(currentVelocity.getDy(), 2));
        double x = collisionPoint.getX();
        double sectionWidth = getCollisionRectangle().getWidth() / 5;
        double upperLeftX = getCollisionRectangle().getUpperLeft().getX();

        int angle = x <= upperLeftX + sectionWidth ? 300
                : x <= upperLeftX + 2 * sectionWidth ? 330
                : x >= upperLeftX + 4 * sectionWidth ? 60
                : x >= upperLeftX + 3 * sectionWidth ? 30
                : 0;

        return Velocity.fromAngleAndSpeed(angle, speed);
    }
}
