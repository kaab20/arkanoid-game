package sprites;

/**
 * ID:214084709
 * @author kamar asli
 */
import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import biuoop.DrawSurface;
import game.Game;
import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;
import logic.BlockRemover;
import logic.Collidable;
import logic.HitListener;
import logic.HitNotifier;

/**
 * The Block class represents a rectangular block in the game.
 * It implements the Collidable and Sprite interfaces to handle collisions and rendering.
 */
public class Block implements Collidable, Sprite, HitNotifier {
    private Rectangle rectangle;
    private boolean border = true;
    private Color color;
    public boolean isWall = false;
    private final List<HitListener> hitListeners = new LinkedList<>();
    /**
     * Constructs a Block with a specified rectangle shape and color.
     *
     * @param shape the rectangle representing the block's shape.
     * @param color the color of the block.
     */
    public Block(Rectangle shape, Color color) {
        this.rectangle = shape;
        this.color = color;
    }
    @Override
    public Rectangle getCollisionRectangle() {
        return rectangle;
    }
    /**
     * Sets the collision rectangle for this object.
     *
     * @param rect the new collision rectangle.
     */
    public void setCollisionRectangle(Rectangle rect) {
        this.rectangle = rect;
    }
    /**
     * Handles the collision logic when an object collides with the block.
     * Reverses the velocity's direction based on the collision point.
     *
     * @param collPoint the point where the collision occurred.
     * @param currVelocity   the velocity of the colliding object before the collision.
     * @return a new Velocity object after the collision.
     */
    @Override
    public Velocity hit(Ball hitter, Point collPoint, Velocity currVelocity) {
        if (!isWall && !ballColorMatch(hitter)) {
            notifyHit(hitter);
            hitter.setColor(this.color);
        }
        double dx = currVelocity.getDx();
        double dy = currVelocity.getDy();
        double epsilon = 1e-5;
        boolean hitVertical = Math.abs(collPoint.getX() - rectangle.getUpperLeft().getX()) < epsilon
                || Math.abs(collPoint.getX() - (rectangle.getUpperLeft().getX() + rectangle.getWidth())) < epsilon;
        boolean hitHorizontal = Math.abs(collPoint.getY() - rectangle.getUpperLeft().getY()) < epsilon
                || Math.abs(collPoint.getY() - (rectangle.getUpperLeft().getY() + rectangle.getHeight())) < epsilon;
        if (hitVertical) {
            dx = -dx;
        }
        if (hitHorizontal) {
            dy = -dy;
        }
        return new Velocity(dx, dy);
    }
    /**
     * Draws the block on the given DrawSurface.
     *
     * @param sur the DrawSurface to draw on.
     */
    @Override
    public void drawOn(DrawSurface sur) {
        sur.setColor(color);
        sur.fillRectangle(((int) rectangle.getUpperLeft().getX()), ((int) rectangle.getUpperLeft().getY()),
                ((int) rectangle.getWidth()), ((int) rectangle.getHeight()));
        sur.setColor(Color.GRAY);
        sur.drawRectangle(((int) rectangle.getUpperLeft().getX()), ((int) rectangle.getUpperLeft().getY()),
                ((int) rectangle.getWidth()), ((int) rectangle.getHeight()));
    }
    /**
     * Notifies the block that time has passed.
     * Currently, this method does nothing, but it may be extended in the future.
     */
    @Override
    public void timePassed() {
    }
    /**
     * Adds the block to the game as both a Collidable and a Sprite.
     *
     * @param game the game to add the block to.
     */
    public void addToGame(Game game) {
        game.addCollidable(this);
        game.addSprite(this);
    }
    /**
     * Removes the block to the collections of collidables and sprites in the game.
     *
     * @param game a {@link Game}.
     */
    public void removeFromGame(Game game) {
        game.removeCollidable(this);
        game.removeSprite(this);
    }

    public void removeHitListener(HitListener hl) {
        hitListeners.remove(hl);
    }
    public void addHitListener(HitListener hl) {
        hitListeners.add(hl);
    }

    /**
     * Changing the default border option.
     *
     * @param b whether or not to draw a border.
     */
    public void setBorder(boolean b) {
        this.border = b;
    }

    public void notifyHit(Ball hitter) {
        for (HitListener hl : hitListeners) {
            hl.hitEvent(this, hitter);
        }

    }

    private boolean ballColorMatch(Ball hitter) {
        return this.color.equals(hitter.getColor());
    }


}
