package sprites;

import biuoop.DrawSurface;

/**
 * ID:214084709
 * Author: kamar asli
 * The Sprite interface represents an object in the game that can be drawn on a DrawSurface
 * and can update its state over time.
 */
public interface Sprite {

    /**
     * Draws the sprite on the given DrawSurface.
     *
     * @param d the DrawSurface to draw on.
     */
    void drawOn(DrawSurface d);

    /**
     * Notifies the sprite that time has passed, allowing it to update its state.
     */
    void timePassed();
}
