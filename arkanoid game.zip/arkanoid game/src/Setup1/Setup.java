package Setup1;

import geometry.Rectangle;
import java.awt.Color;

/**
 * ID:214084709.
 * Updated Setup to match the first screenshot.
 */
public final class Setup {
    public static final int FRAMES_PER_SECOND = 60;

    // Updated brick colors to match the first screenshot
    public static final Color[] COLORS = {
            Color.GRAY,
            Color.RED,
            Color.YELLOW,
            Color.BLUE,
            Color.WHITE
    };

    // Paddle color updated to yellow
    public static final Color PADDLE_COLOR = Color.YELLOW;

    // Paddle dimensions adjusted
    public static final Rectangle PADDLE_RECT;

    // Updated window settings
    public static final int WIN_WIDTH = 800;
    public static final int WIN_HEIGHT = 600;

    // Background color updated to green
    public static final Color WIN_BG_COLOR = Color.GREEN;

    // Wall settings remain the same
    public static final Color WALLS_COLOR = Color.DARK_GRAY;
    public static final int WALLS_SIZE = 10;

    // Updated brick dimensions to match the first screenshot
    public static final int BRICKS_WIDTH = 40;  // Reduced width
    public static final int BRICKS_HEIGHT = 20; // Reduced height

    // Ball settings updated to a single ball with a white color
    public static final int BALL_SIZE = 10;
    public static final int BALL_SPEED = 5;
    public static final Color BALL_COLOR = Color.WHITE;
    public static int NUMBER_OF_BALLS = 1;  // Only one ball

    // Static initializer block to calculate paddle rectangle
    static {
        final int paddleWidth = 80;  // Reduced paddle width
        final int paddleHeight = 15; // Reduced paddle height
        PADDLE_RECT = new Rectangle(
                (WIN_WIDTH - paddleWidth) / 2.0,
                WIN_HEIGHT - paddleHeight - WALLS_SIZE,
                paddleWidth,
                paddleHeight
        );
    }
}

