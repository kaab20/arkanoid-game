package collections; /**
 * ID:214084709
 * @author kamar asli
 */
import logic.CollisionInfo;
import logic.Collidable;
import geometry.Line;
import geometry.Rectangle;
import geometry.Point;
import java.util.ArrayList;
import java.util.List;
/**
 * Represents a game environment that manages collidable objects.
 */
public class GameEnvironment {
    private List<Collidable> objreshema = new ArrayList<>();
    /**
     * Constructs a new GameEnvironment with an empty list of collidable objects.
     */
    public GameEnvironment() {
    }
    /**
     * Adds a collidable object to the environment.
     *
     * @param c the collidable object to be added
     */
    public void addCollidable(Collidable c) {
        this.objreshema.add(c);
    }
    /**
     * Finds the closest collision point between a line and the collidable objects in the environment.
     *
     * @param maslol the line to check for collisions
     * @return the closest collision information, or null if there are no collisions
     */
    public CollisionInfo getClosestCollision(Line maslol) {
        CollisionInfo closestColl = null;
        double closestDistance = Double.MAX_VALUE;
        int i = 0;
        while (i < this.objreshema.size()) {
            Collidable obj = this.objreshema.get(i);
            Rectangle rec = obj.getCollisionRectangle();
            Point collisionPoint = maslol.closestIntersectionToStartOfLine(rec);
            if (collisionPoint != null) {
                double distance = maslol.start().distance(collisionPoint);
                if (distance < closestDistance) {
                    closestDistance = distance;
                    closestColl = new CollisionInfo(collisionPoint, obj);
                }
            }
            i++;
        }
        return closestColl;
    }
    public void removeCollidable(Collidable c) {
        objreshema.remove(c);
    }

}
