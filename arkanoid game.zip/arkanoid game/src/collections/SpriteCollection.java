package collections;

import biuoop.DrawSurface;
import sprites.Sprite;

import java.util.LinkedList;
import java.util.List;
/**
 * ID:214084709.
 * @author kamar asli
 */
/**The SpriteCollection class manages a collection of Sprite objects.
 * It provides functionality to add sprites, notify them of time passage,
 * and draw them on a specified drawing surface.
 */
public class SpriteCollection {
    private final List<Sprite> sprites = new LinkedList<>();
    /**
     * Adds a sprite to the collection.
     *
     * @param s the sprite to be added to the collection.
     */
    public void addSprite(Sprite s) {
        sprites.add(s);
    }
    /**
     * Notifies all sprites in the collection that time has passed,
     * allowing them to update their state accordingly.
     */
    public void notifyAllTimePassed() {
        int i = 0;
        while (i < sprites.size()) {
            sprites.get(i).timePassed();
            i++;
        }
    }
    /**
     * Draws all sprites in the collection on the specified drawing surface.
     *
     * @param d the drawing surface on which to draw the sprites
     */
    public void drawAllOn(DrawSurface d) {
        int j = 0;
        while (j < sprites.size()) {
            sprites.get(j).drawOn(d);
            j++;
        }
    }
    public void removeSprite(Sprite s) {
        sprites.remove(s);
    }
}